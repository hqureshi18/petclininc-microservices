package com.example.petclinic.service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.client.RestTemplate;

import java.net.URI;

public class VetService {
    private static final Logger log = LoggerFactory.getLogger(VetService.class);

    RestTemplate restTemplate;
    public  VetService(RestTemplate restTemplate){
        this.restTemplate= restTemplate;
    }
    public VetService saveVet(VetService vetService) {
        URI uri = URI.create("http://localhost:9091/ownerapi/vet/addVetService");

        VetService response = restTemplate.postForObject(uri,vetService,VetService.class);
        log.info(response.toString());
        return response;
    }
}
