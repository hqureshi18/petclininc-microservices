package com.example.petclinic.service.config;

public class VisitService {
}
